package com.vvs.training.hospital.daoapi;

import com.vvs.training.hospital.datamodel.Nurse;

public interface INurseDao extends IGenericDao<Nurse> {
	
}
