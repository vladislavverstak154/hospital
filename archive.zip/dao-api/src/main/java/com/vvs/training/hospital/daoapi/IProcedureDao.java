package com.vvs.training.hospital.daoapi;

import com.vvs.training.hospital.datamodel.Procedure;

public interface IProcedureDao extends IGenericDao<Procedure> {
	
}
