package com.vvs.training.hospital.daoapi;

import com.vvs.training.hospital.datamodel.Drug;

public interface IDrugDao extends IGenericDao<Drug> {
	
}
