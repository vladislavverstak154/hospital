package com.vvs.training.hospital.daoapi;

import com.vvs.training.hospital.datamodel.Patient;

public interface IPatientDao extends IGenericDao<Patient> {
	
}
