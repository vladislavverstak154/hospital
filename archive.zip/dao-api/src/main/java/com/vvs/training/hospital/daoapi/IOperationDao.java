package com.vvs.training.hospital.daoapi;

import com.vvs.training.hospital.datamodel.Operation;

public interface IOperationDao extends IGenericDao<Operation>{
	
}
