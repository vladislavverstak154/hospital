package com.vvs.training.hospital.daoapi;

import com.vvs.training.hospital.datamodel.Cure;


public interface ICureDao extends IGenericDao<Cure> {
	
}
