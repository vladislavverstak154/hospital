package com.vvs.training.hospital.daodb.impl;

import com.vvs.training.hospital.daoapi.IProcedureDao;
import com.vvs.training.hospital.datamodel.Procedure;


public class ProcedureDaoImpl extends GenericDaoImpl<Procedure> implements IProcedureDao {

}
