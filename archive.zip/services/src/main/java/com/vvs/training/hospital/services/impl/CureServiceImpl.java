package com.vvs.training.hospital.services.impl;

import java.util.List;

import com.vvs.training.hospital.services.CureService;
import com.vvs.training.hospital.datamodel.Cure;

public class CureServiceImpl implements CureService {

	@Override
	public void saveAll(List<Cure> cures) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void save(Cure cure) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Long id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Cure get(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Cure> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	

}
