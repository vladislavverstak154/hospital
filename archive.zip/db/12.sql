﻿insert into doctor(first_name,second_name,last_name) values('delicious moobars','uuf','dddd');
select*from doctor where id = 1; 