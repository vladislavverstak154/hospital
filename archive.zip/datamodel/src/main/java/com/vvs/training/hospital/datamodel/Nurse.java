package com.vvs.training.hospital.datamodel;

import com.vvs.training.hospital.annotations.Table;

@Table(name="nurse")
public class Nurse extends Person {
	
}
